﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Input;
using Данилин_Пр1.Models;
using System.Windows;
using System.Runtime.InteropServices;

namespace Данилин_Пр1.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string name = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        private byte _r;
        public byte R 
        {
            get 
            {
                return _r; 
            }
            set
            {
                _r = value;
                OnPropertyChanged();
                UpdateColor();
            }
        }

        private byte _g;
        public byte G
        {
            get
            {
                return _g;
            }
            set
            {
                _g = value;
                OnPropertyChanged();
                UpdateColor();
            }
        }

        private byte _b;
        public byte B
        {
            get
            {
                return _b;
            }
            set
            {
                _b = value;
                OnPropertyChanged();
                UpdateColor();
            }
        }

        private byte _a = 255;
        public byte A
        {
            get
            {
                return _a;
            }
            set
            {
                _a = value;
                OnPropertyChanged();
                UpdateColor();
            }
        }

        private Brush _brush;
        public Brush Brush
        {
            get
            {
                return _brush; 
            }
            set
            {
                _brush = value;
                OnPropertyChanged();
            }
        }

        public void UpdateColor()
        {
            Brush = new SolidColorBrush(Color.FromArgb(_a, _r, _g, _b));
        }

        public DelegateCommand updateClipboardCommand 
        {
            get 
            {
                return new DelegateCommand(obj => { UpdateClipboard(); });
            }
        }

        private void UpdateClipboard()
        {
            MessageBox.Show
            (
            $"Цвет скопирован. \n" +
            $"Ваш цвет в hex: {Color.FromRgb(_r, _g, _b)}\n" +
            $"Ваш цвет в rgb: R:{_r} G:{_g} B:{_b}\n" +
            $"Прозрачность (Alpha): {_a}"
            );
            Clipboard.SetText
            (
                $"Hex: {Color.FromRgb(_r, _g, _b)}\n" +
                $"Rgb: {_r} {_g} {_b}\n" +
                $"Alpha: {_a}"
            );
        }
    }
}
